# Pacote instalável do INVOS

Siga as instruções em `../INSTALAR.md` para instalar o INVOS.
