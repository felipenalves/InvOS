# Instalar o INVOS pelo ZIP

Requisito: Node.js 18 ou superior.

## Criar um projeto novo

Abra o terminal na pasta extraída e rode:

```bash
node package/bin/invos.js init --name meu-negocio
cd meu-negocio
```

Abra a pasta criada no seu agente de IA e rode /instalar.

## Instalar em uma pasta existente

```bash
node package/bin/invos.js install --dir "/caminho/do/seu-projeto"
```
